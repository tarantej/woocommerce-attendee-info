<?php
/** 
 * Plugin Name: Woocommerce Attendee Information
 * Plugin URI: https://woocommerce.com/
 * Description: Captures additional attendee information for events on checkout page. Customized checkout layout
 * Version: 1.0
 * Author: WooCommerce
 * Author URI: http://woocommerce.com/
 * Text Domain: wpas_attendeeinfo
 * Domain Path: /lang
 * @package WPAS_ATTENDEEINFO
 * @since WPAS 4.0
 */
/*
 * LICENSE:
 * Woocommerce Attendee Information is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * Woocommerce Attendee Information is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * Please see <http://www.gnu.org/licenses/> for details.
*/
if (!defined('ABSPATH')) exit;
if (!class_exists('Woocommerce_Attendee_Information')):
	/**
	 * Main class for Woocommerce Attendee Information
	 *
	 * @class Woocommerce_Attendee_Information
	 */
	final class Woocommerce_Attendee_Information {
		/**
		 * @var Woocommerce_Attendee_Information single instance of the class
		 */
		private static $_instance;
		public $textdomain = 'wpas_attendeeinfo';
		public $app_name = 'wpas_attendeeinfo';
		/**
		 * Main Woocommerce_Attendee_Information Instance
		 *
		 * Ensures only one instance of Woocommerce_Attendee_Information is loaded or can be loaded.
		 *
		 * @static
		 * @see WPAS_ATTENDEEINFO()
		 * @return Woocommerce_Attendee_Information - Main instance
		 */
		public static function instance() {
			if (!isset(self::$_instance)) {
				self::$_instance = new self();
				self::$_instance->define_constants();
				self::$_instance->includes();
				self::$_instance->load_plugin_textdomain();
				add_filter('the_content', array(
					self::$_instance,
					'change_content'
				));
				add_action('admin_menu', array(
					self::$_instance,
					'display_settings'
				));
				add_filter('template_include', array(
					self::$_instance,
					'show_template'
				));
			}
			return self::$_instance;
		}
		/**
		 * Cloning is forbidden.
		 */
		public function __clone() {
			_doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?', $this->textdomain) , '1.0');
		}
		/**
		 * Define Woocommerce_Attendee_Information Constants
		 *
		 * @access private
		 * @return void
		 */
		private function define_constants() {
			define('WPAS_ATTENDEEINFO_VERSION', '1.0');
			define('WPAS_ATTENDEEINFO_AUTHOR', 'WooCommerce');
			define('WPAS_ATTENDEEINFO_NAME', 'Woocommerce Attendee Information');
			define('WPAS_ATTENDEEINFO_PLUGIN_FILE', __FILE__);
			define('WPAS_ATTENDEEINFO_PLUGIN_DIR', plugin_dir_path(__FILE__));
			define('WPAS_ATTENDEEINFO_PLUGIN_URL', plugin_dir_url(__FILE__));
		}
		/**
		 * Include required files
		 *
		 * @access private
		 * @return void
		 */
		private function includes() {
			//these files are in all apps
			if (!function_exists('emd_mb_meta')) {
				require_once WPAS_ATTENDEEINFO_PLUGIN_DIR . 'assets/ext/emd-meta-box/emd-meta-box.php';
			}
			if (!function_exists('emd_translate_date_format')) {
				require_once WPAS_ATTENDEEINFO_PLUGIN_DIR . 'includes/date-functions.php';
			}
			if (!function_exists('emd_get_hidden_func')) {
				require_once WPAS_ATTENDEEINFO_PLUGIN_DIR . 'includes/common-functions.php';
			}
			if (!class_exists('Emd_Entity')) {
				require_once WPAS_ATTENDEEINFO_PLUGIN_DIR . 'includes/entities/class-emd-entity.php';
			}
			if (!function_exists('emd_get_template_part')) {
				require_once WPAS_ATTENDEEINFO_PLUGIN_DIR . 'includes/layout-functions.php';
			}
			//the rest
			do_action('emd_ext_include_files');
			//app specific files
			if (!function_exists('emd_show_settings_page')) {
				require_once WPAS_ATTENDEEINFO_PLUGIN_DIR . 'includes/admin/settings-functions.php';
			}
			if (is_admin()) {
				//these files are in all apps
				if (!function_exists('emd_display_store')) {
					require_once WPAS_ATTENDEEINFO_PLUGIN_DIR . 'includes/admin/store-functions.php';
				}
				//the rest
				require_once WPAS_ATTENDEEINFO_PLUGIN_DIR . 'includes/admin/glossary.php';
			}
			require_once WPAS_ATTENDEEINFO_PLUGIN_DIR . 'includes/plugin-app-functions.php';
			require_once WPAS_ATTENDEEINFO_PLUGIN_DIR . 'includes/class-install-deactivate.php';
			require_once WPAS_ATTENDEEINFO_PLUGIN_DIR . 'includes/entities/class-emd-contact.php';
			require_once WPAS_ATTENDEEINFO_PLUGIN_DIR . 'includes/entities/class-emd-attendee.php';
			require_once WPAS_ATTENDEEINFO_PLUGIN_DIR . 'includes/scripts.php';
			require_once WPAS_ATTENDEEINFO_PLUGIN_DIR . 'includes/content-functions.php';
		}
		/**
		 * Loads plugin language files
		 *
		 * @access public
		 * @return void
		 */
		public function load_plugin_textdomain() {
			$locale = apply_filters('plugin_locale', get_locale() , 'wpas_attendeeinfo');
			$mofile = sprintf('%1$s-%2$s.mo', 'wpas_attendeeinfo', $locale);
			$mofile_shared = sprintf('%1$s-emd-plugins-%2$s.mo', 'wpas_attendeeinfo', $locale);
			$lang_file_list = Array(
				'emd-plugins' => $mofile_shared,
				'wpas_attendeeinfo' => $mofile
			);
			foreach ($lang_file_list as $lang_key => $lang_file) {
				$localmo = WPAS_ATTENDEEINFO_PLUGIN_DIR . '/lang/' . $lang_file;
				$globalmo = WP_LANG_DIR . '/wpas_attendeeinfo/' . $lang_file;
				if (file_exists($globalmo)) {
					load_textdomain($lang_key, $globalmo);
				} elseif (file_exists($localmo)) {
					load_textdomain($lang_key, $localmo);
				} else {
					load_plugin_textdomain($lang_key, false, WPAS_ATTENDEEINFO_PLUGIN_DIR . '/lang/');
				}
			}
		}
		/**
		 * Changes content on frontend views
		 *
		 * @access public
		 * @param string $content
		 *
		 * @return string $content
		 */
		public function change_content($content) {
			$tools = get_option($this->app_name . '_tools');
			if (!is_admin() && !empty($tools['disable_emd_templates'])) {
				if (post_password_required()) {
					$content = get_the_password_form();
				} else {
					$mypost_type = get_post_type();
					if ($mypost_type == 'post' || $mypost_type == 'page') {
						$mypost_type = "emd_" . $mypost_type;
					}
					$ent_list = get_option($this->app_name . '_ent_list');
					if (in_array($mypost_type, array_keys($ent_list)) && class_exists($mypost_type)) {
						$func = "change_content";
						$obj = new $mypost_type;
						$content = $obj->$func($content);
					}
				}
			}
			return $content;
		}
		/**
		 * Creates plugin page in menu with submenus
		 *
		 * @access public
		 * @return void
		 */
		public function display_settings() {
			add_menu_page(__('Attendee', $this->textdomain) , __('Attendee', $this->textdomain) , 'manage_options', $this->app_name, array(
				$this,
				'display_glossary_page'
			));
			add_submenu_page($this->app_name, __('Glossary', $this->textdomain) , __('Glossary', $this->textdomain) , 'manage_options', $this->app_name, array(
				$this,
				'display_glossary_page'
			));
			add_submenu_page($this->app_name, __('Settings', $this->textdomain) , __('Settings', $this->textdomain) , 'manage_options', $this->app_name . '_settings', array(
				$this,
				'display_settings_page'
			));
			add_submenu_page($this->app_name, __('Add-Ons', $this->textdomain) , __('Add-Ons', $this->textdomain) , 'manage_options', $this->app_name . '_store', array(
				$this,
				'display_store_page'
			));
			add_submenu_page($this->app_name, __('Designs', $this->textdomain) , __('Designs', $this->textdomain) , 'manage_options', $this->app_name . '_designs', array(
				$this,
				'display_design_page'
			));
			add_submenu_page($this->app_name, __('Support', $this->textdomain) , __('Support', $this->textdomain) , 'manage_options', $this->app_name . '_support', array(
				$this,
				'display_support_page'
			));
			//add submenu page under app settings page
			do_action('emd_ext_add_menu_pages', $this->app_name);
		}
		/**
		 * Calls settings function to display glossary page
		 *
		 * @access public
		 * @return void
		 */
		public function display_glossary_page() {
			do_action($this->app_name . '_settings_glossary');
		}
		public function display_store_page() {
			emd_display_store($this->textdomain);
		}
		public function display_design_page() {
			emd_display_design($this->textdomain);
		}
		public function display_support_page() {
			emd_display_support($this->textdomain, 1, 'woocommerce-attendee-information');
		}
		public function display_settings_page() {
			do_action('emd_show_settings_page', $this->app_name);
		}
		/**
		 * Displays single, archive, tax and no-access frontend views
		 *
		 * @access public
		 * @return string, $template:emd template or template
		 */
		public function show_template($template) {
			return emd_show_template($this->app_name, WPAS_ATTENDEEINFO_PLUGIN_DIR, $template);
		}
	}
endif;
/**
 * Returns the main instance of Woocommerce_Attendee_Information
 *
 * @return Woocommerce_Attendee_Information
 */
function WPAS_ATTENDEEINFO() {
	return Woocommerce_Attendee_Information::instance();
}
// Get the Woocommerce_Attendee_Information instance
WPAS_ATTENDEEINFO();
